package com.example.ads;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.adslibrary.AdsGallery;

import java.util.ArrayList;
import java.util.List;

/**
 * @author RH
 */
public class MainActivity extends AppCompatActivity {
    private List<String> urls = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        AdsGallery adsGallery = findViewById(R.id.ads);
        adsGallery.init();

        urls.add("https://static.hgobox.com/worker/1/image/2019/05/14/20190514175006537-p3.jpg");
        urls.add("https://static.hgobox.com/worker/1/video/2019/05/14/20190514165817660-test2.mp4");
        urls.add("https://static.hgobox.com/worker/1/image/2019/05/14/20190514171055360-p1.jpg");
        urls.add("https://static.hgobox.com/worker/1/image/2019/05/14/20190514171050980-p2.jpg");
        adsGallery.setData(urls);
    }
}
