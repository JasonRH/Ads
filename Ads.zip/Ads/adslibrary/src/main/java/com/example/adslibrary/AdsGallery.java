package com.example.adslibrary;

import android.content.Context;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import java.util.ArrayList;
import java.util.List;

import androidx.viewpager2.widget.ViewPager2;

/**
 * @author RH
 * @date 2019/5/20
 */
public class AdsGallery extends FrameLayout {

    private ViewPager2 viewPager2;

    private AdAdapter pagerAdapter;
    private List<String> urls = new ArrayList<>();


    public AdsGallery(Context context) {
        super(context);
    }

    public void init() {
        initView();
        pagerAdapter = new AdAdapter(urls);
        viewPager2.setAdapter(pagerAdapter);
        //设置预加载数为0
        viewPager2.setOffscreenPageLimit(0);
        viewPager2.setOrientation(ViewPager2.ORIENTATION_HORIZONTAL);
    }

    private void initView() {
        /*
         * 用Java代码创建布局
         */
        viewPager2 = new ViewPager2(getContext());
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT);
        viewPager2.setLayoutParams(params);
        this.addView(viewPager2);
    }

    public void setData(List<String> list) {
        urls.clear();
        urls.addAll(list);
        pagerAdapter.notifyDataSetChanged();
    }

}
