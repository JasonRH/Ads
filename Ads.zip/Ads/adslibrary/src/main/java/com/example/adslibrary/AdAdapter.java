package com.example.adslibrary;

import android.content.Context;

import android.support.v7.widget.AppCompatImageView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.VideoView;

import com.bumptech.glide.Glide;
import com.example.adslibrary.image.MyGlideOptions;

import java.util.List;

import androidx.annotation.NonNull;

import androidx.recyclerview.widget.RecyclerView;


/**
 * @author RH
 * @date 2019/5/20
 */
public class AdAdapter extends RecyclerView.Adapter<AdAdapter.ViewHolder> {

    private List<String> urls;
    private Context mContext;

    public AdAdapter(List<String> urls) {
        this.urls = urls;
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        private AppCompatImageView imageView;
        private VideoView videoView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.image);
            videoView = itemView.findViewById(R.id.video);
        }
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (mContext == null) {
            mContext = parent.getContext();
        }
        View view = LayoutInflater.from(mContext).inflate(R.layout.item_adapter_ad, parent, false);
        final ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        String url = urls.get(position);
        if (url.endsWith("mp4")) {
            //视频
            holder.imageView.setVisibility(View.GONE);
            Log.e("AdAdapter", "加载视频");

        } else {
            //图片
            holder.videoView.setVisibility(View.GONE);
            Glide.with(mContext).load(url).apply(MyGlideOptions.OPTIONS).into(holder.imageView);
        }

    }


    @Override
    public int getItemCount() {
        return urls.size();
    }
}
