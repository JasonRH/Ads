package com.example.adslibrary.image;

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

/**
 * @author RH
 * @date 2018/10/29
 * <p>
 * 使用Glide必须自定义类继承AppGlideModule
 */
@GlideModule
public class MyAppGlideModule extends AppGlideModule {
}
